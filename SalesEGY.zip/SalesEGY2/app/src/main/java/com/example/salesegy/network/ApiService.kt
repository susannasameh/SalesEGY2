package com.example.salesegy.network

import com.example.salesegy.model.AllData
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("newusersync.php")
    suspend fun getAllData(): Response<AllData>


    @GET("newusersync.php")
    fun getData(): Call<AllData>

}